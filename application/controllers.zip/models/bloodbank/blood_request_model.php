<?php

class blood_request_model {
    function __construct() {
        parent::__construct();        
    }
    
    
}
