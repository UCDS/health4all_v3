
	<section id="right">
		<h1>Reports</h1>	
		<div>
			<ul>
				<li><a href="<?php echo base_url();?>reports/op_summary">Out Patient Summary - Department wise</a></li>
				<li><a href="<?php echo base_url();?>reports/op_detail">Out Patient Detailed Report</a></li>
		</div>
	</section>