
	<div class="row">
		<h1>Contact Us</h1>
		<p>For any queries, contact us at +91-8008-884422.</p>
		<p>Health4all - a Free and Open Source application supported by <a href="http://www.yousee.in">YouSee</a></p>
	</div>
