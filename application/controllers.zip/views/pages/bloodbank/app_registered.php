<div class="col-md-10 col-sm-9">
	<p><?php echo $msg; ?></p>
	<p>
				For any further details, you can write to this email-ID redcross.bloodbankhyd@gmail.com or 
				call us at 040-27633087.
				</p>
</div>
