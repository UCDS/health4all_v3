  <div class="container">

      <?php echo form_open('user_panel/form_layout',array('role'=>'form')); ?>
		<div class="row">
				<div class="col-md-10">
				</div>
		</div>
      </form>

    </div>