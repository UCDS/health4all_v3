</div>
<!-- End container -->
</div>
<!-- End Wrap -->

<div id="footer">
      <div class="container">
        <p class="text-muted">
		Health4All - a Free and Open Source application supported by <a href="https://yousee.in/c4c" target="_blank">YouSee</a>
		</p>
      </div>
</div>
</body>
</html>